package com.shpp.p2p.cs.dbabin.assignment2;

import acm.graphics.GOval;
import acm.graphics.GRect;
import com.shpp.cs.a.graphics.WindowProgram;

import java.awt.*;

/**
 * This code can draw four oval and square at middle.
 * If u will change size of oval square size will be change also
 */
public class Assignment2Part2 extends WindowProgram {
    //This two variable set size of the window
    public static final int APPLICATION_WIDTH = 300;
    public static final int APPLICATION_HEIGHT = 300;
    /*
    I don't know which variant u like. U can set how it will work.
    True - code will use getHeight and getWidth divided into 3 for set size of oval
    False - code will use variables OVAL_SIZE_X and OVAL_SIZE_Y for set size of oval
     */
    public static final boolean TUMBLER = true;
    //For set width of oval
    public static final int OVAL_SIZE_X = 100;
    //For set height of oval
    public static final int OVAL_SIZE_Y = 100;

    public void run() {
        drawPawprint();
    }

    /**
     * Basic method for drawing a picture.
     * This method consist of two methods:
     * First - for create four ovals
     * Second - for create one square at middle
     */
    private void drawPawprint() {
        createOval();
        createSquare();
    }

    /**
     * This method get two parameters width and height and drawing four black oval at every of four corner.
     * Every of four oval have a name corresponding positions keys on the keyboard.
     * For example Q located in the upper left corner.
     */
    private void createOval() {
        //We have getWidth and getHeight methods which is max width and man height of the window
        //If we subtract getWidth form getWidth we get zero position of width
        //We can also do with getHeight for get a zero position of height
        GOval Q = new GOval(getWidth() - getWidth()
                , getHeight() - getHeight()
                , ovalSizeX(), ovalSizeY());
        //Here we add color
        Q.setFilled(true);
        Q.setFillColor(Color.black);
        add(Q);
        //If we need position oval at upper left corner we must subtract size of oval from getWidth
        GOval W = new GOval(getWidth() - ovalSizeX(),
                getHeight() - getHeight()
                , ovalSizeX(), ovalSizeY());
        W.setFilled(true);
        W.setFillColor(Color.black);
        add(W);
        //If we  need position oval at lower right corner we must get zero position of width
        //like we did it before and subtract size of oval from getHeight
        GOval A = new GOval(getWidth() - getWidth()
                , getHeight() - ovalSizeY(),
                ovalSizeX(), ovalSizeY());
        A.setFilled(true);
        A.setFillColor(Color.black);
        add(A);
        //If we need position oval at lower left corner  we must subtract size of oval form getHeight
        // and than form getWidth
        GOval S = new GOval(getWidth() - ovalSizeX(),
                getHeight() - ovalSizeY()
                , ovalSizeX(), ovalSizeY());
        S.setFilled(true);
        S.setFillColor(Color.black);
        add(S);
    }

    /**
     * This method create square at middle of window. This square size always depends on size of oval.
     * Also this square always cover quarter of every oval.
     */
    private void createSquare() {
        //For get square who always cover quarter of every oval we subtract max width/height from diameter of oval
        //For get  square at middle of window we divide max size on two and subtract from hals of size square
        GRect square = new GRect((getWidth() / 2.0) - ((getWidth() - ovalSizeX()) / 2),
                (getHeight() / 2.0) - ((getHeight() - ovalSizeY()) / 2),
                getWidth() - ovalSizeX(), getHeight() - ovalSizeY());
        square.setFilled(true);
        square.setFillColor(Color.WHITE);
        square.setColor(Color.WHITE);
        add(square);
    }

    /**
     * This method get true or false and
     *
     * @return needed width of ovals
     */
    private double ovalSizeX() {
        if (TUMBLER) {
            return getWidth() / 3.0;
            //If TUMBLER is true width of oval always will be equal third of width of window
        } else {
            //If TUMBLER is false width of oval always will be equal value in OVAL_SIZE_X
            return OVAL_SIZE_X;
        }
    }

    /**
     * This method get true or false and
     *
     * @return needed height of ovals
     */
    private double ovalSizeY() {
        if (TUMBLER) {
            return getHeight() / 3.0;
            //If TUMBLER is true height of oval always will be equal third of height of window
        } else {
            //If TUMBLER is false height of oval always will be equal value in OVAL_SIZE_Y
            return OVAL_SIZE_Y;
        }
    }
}
