package com.shpp.p2p.cs.dbabin.assignment2;

import acm.graphics.GLabel;
import acm.graphics.GRect;
import com.shpp.cs.a.graphics.WindowProgram;

import java.awt.*;

/**
 * This method can draw flag of Belgium specified size
 */
public class Assignment2Part4 extends WindowProgram {
    //Height of flag
    private static final double FLAG_HEIGHT = 150;
    //Width of flag
    private static final double FLAG_WIDTH = 75;
    //Width of window
    public static final int APPLICATION_WIDTH = 300;
    //Height of window
    public static final int APPLICATION_HEIGHT = 300;

    public void run() {
        drawFlag(FLAG_WIDTH, FLAG_HEIGHT);
        drawText();
    }

    /**
     * This method write text "Flag of Belgium" in the lower left corner
     */
    private void drawText() {
        GLabel text = new GLabel("Flag of Belgium", getWidth() -
                //86 is width of text. 2 is descent under baseline.
                86, getHeight() - 2);
        add(text);
    }

    /**
     * This method get a sizes of every part of flag
     *
     * @param x This width of parts of flag
     * @param y This height of parts of flag
     */
    private void drawFlag(double x, double y) {
        firstPartOfFlag(x, y);
        secondPartOfFlag(x, y);
        thirdPartOfFlag(x, y);
    }

    /**
     * This method make central part of flag
     *
     * @param x This width of parts of flag
     * @param y This height of parts of flag
     */
    private void thirdPartOfFlag(double x, double y) {
        GRect middlePart = new GRect(
                //Divides maximal sizes of window and sizes of part of flag by 2 for get
                //positions this part in middle of window
                (getWidth() / 2.0) - (x / 2.0),
                (getHeight() / 2.0) - (y / 2),
                x, y);
        middlePart.setFilled(true);
        middlePart.setFillColor(Color.YELLOW);
        middlePart.setColor(Color.YELLOW);
        add(middlePart);
    }

    /**
     * This method make left part of flag
     *
     * @param x This width of parts of flag
     * @param y This height of parts of flag
     */
    private void firstPartOfFlag(double x, double y) {
        GRect leftPart = new GRect(
                //Get size on 1.5 bigger then the part of flag for position it at needed place
                (getWidth() / 2.0) - (x * 1.5),
                (getHeight() / 2.0) - (y / 2),
                x, y);
        leftPart.setFilled(true);
        leftPart.setFillColor(Color.BLACK);
        leftPart.setColor(Color.BLACK);
        add(leftPart);
    }

    /**
     * This method make right part of flag
     *
     * @param x This width of parts of flag
     * @param y This height of parts of flag
     */
    private void secondPartOfFlag(double x, double y) {
        GRect rightPart = new GRect(
                //Get coordinates middle of window + half of part of flag
                //for to place right part of flag
                (getWidth() / 2.0) + (x / 2),
                (getHeight() / 2.0) - (y / 2),
                x, y);
        rightPart.setFilled(true);
        rightPart.setFillColor(Color.RED);
        rightPart.setColor(Color.RED);
        add(rightPart);
    }
}
