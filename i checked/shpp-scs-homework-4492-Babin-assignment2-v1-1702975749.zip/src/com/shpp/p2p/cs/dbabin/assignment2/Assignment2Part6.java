package com.shpp.p2p.cs.dbabin.assignment2;

import acm.graphics.GOval;
import com.shpp.cs.a.graphics.WindowProgram;

import java.awt.*;

/**
 * This code create set number and size ovals which look like caterpillar
 */
public class Assignment2Part6 extends WindowProgram {
    //Size of ovals
    private static final double OVAL_RADIUS = 60;
    //Number of ovals
    private static final double NUM_OVALS = 8;

    public void run() {
        drawCaterpillar();
    }

    /**
     * This is basic method which contains cycle which
     * create needed number of ovals.
     */
    private void drawCaterpillar() {
        for (int i = 0; i < NUM_OVALS; i++) {
            //This cycle make specified quantity of ovals
            //and send the value of variable i to determine the position of ovals
            drawOval(caterpillarPartsPositionX(i), caterpillarPartsPositionY(i));
        }
    }

    /**
     * This method set position of every oval in width
     *
     * @param i - oval number
     * @return - position of ovals in width
     */
    private double caterpillarPartsPositionX(double i) {
        //Each, except first, ovals covers the previous one at 70%
        //For get position of every oval we multiply them by their number
        return  OVAL_RADIUS * 0.7 * i;
    }

    /**
     * This method set height of every oval
     *
     * @param i oval number
     * @return - position of ovals in height
     */
    private double caterpillarPartsPositionY(double i) {
        double Y = 0;
        //If i is honest oval will be position in middle of window
        if (i % 2 == 0) {
            Y = getMidY();
            //If i is odd oval will be position on half of OVAL_RADIUS higher than middle of window
        } else {
            Y = getMidY() - OVAL_RADIUS * 0.5;
        }
        return Y;
    }

    /**
     * This method set the parameter of oval
     *
     * @param X - height of oval
     * @param Y - width of oval
     */
    private void drawOval(double X, double Y) {
        //Position and size of oval
        GOval caterpillar = new GOval(X, Y, OVAL_RADIUS, OVAL_RADIUS);
        //Color of oval
        caterpillar.setFilled(true);
        caterpillar.setFillColor(Color.GREEN);
        caterpillar.setColor(Color.RED);
        add(caterpillar);
    }

    /**
     * This method needed to get center by height
     *
     * @return - center by height
     */
    private double getMidY() {
        return getHeight() / 2.0;
    }
}
