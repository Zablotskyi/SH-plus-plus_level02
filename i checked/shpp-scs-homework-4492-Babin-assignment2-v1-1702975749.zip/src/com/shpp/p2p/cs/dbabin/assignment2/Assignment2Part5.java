package com.shpp.p2p.cs.dbabin.assignment2;

import acm.graphics.GRect;
import com.shpp.cs.a.graphics.WindowProgram;

import java.awt.*;

/**
 * This code make array of square.
 * U can change number of rows,cols, size of squares and spacing between
 */
public class Assignment2Part5 extends WindowProgram {
    /* The number of rows and columns in the grid, respectively. */
    private static final int NUM_ROWS = 5;
    private static final int NUM_COLS = 6;

    /* The width and height of each box. */
    private static final double BOX_SIZE = 40;

    /* The horizontal and vertical spacing between the boxes. */
    private static final double BOX_SPACING = 10;

    public void run() {
        makeOpticIllusion();
    }

    /**
     * This method set number of rows and send start height of draw
     */
    private void makeOpticIllusion() {
        double Y = getStartPositionY();
        //This cycle make a rows
        for (int i = 0; i < NUM_ROWS; i++) {
            //If it's first square we use start height of draw
            if (i == 0) {
                makeCols(Y);
            }
            //If it's other square we add to start height of draw size of box and size of spacing between
            if (i > 0) {
                Y += BOX_SIZE + BOX_SPACING;
                makeCols(Y);
            }
        }
    }

    /**
     * This method set number of cols and send start width of draw
     */
    private void makeCols(double Y) {
        double X = getStartPositionX();
        //This cycle make a cols
        for (int i = 0; i < NUM_COLS; i++) {
            //If it's first square we use start height of draw
            if (i == 0) {
                makeSquares(X, Y);
            }
            //If it's other square we add to start height of draw size of box and size of spacing between
            if (i > 0) {
                X += BOX_SIZE + BOX_SPACING;
                makeSquares(X, Y);
            }
        }
    }

    /**
     * This method draw a square on given coordinates
     *
     * @param X This needed width for every square
     * @param Y This needed height for every square
     */

    private void makeSquares(double X, double Y) {
        //Here set position and size
        GRect square = new GRect(X, Y, BOX_SIZE, BOX_SIZE);
        //Color settings
        square.setFilled(true);
        square.setFillColor(Color.BLACK);
        square.setColor(Color.BLACK);
        add(square);
    }

    /**
     * @return -The position of first square X-axis
     */
    private double getStartPositionX() {
        //Calculate middle of window X-axis
        double WIN_MID_X = getWidth() / 2.0;
        //Calculate half of  draw size X-axis
        double DRAW_SIZE_X = ((BOX_SIZE * NUM_COLS) + (BOX_SPACING * NUM_COLS)) / 2;
        //Get position of first square X-axis
        return WIN_MID_X - DRAW_SIZE_X;
    }

    /**
     * @return -The position of first square Y-axis
     */
    private double getStartPositionY() {
        //Calculate middle of window Y-axis
        double WIN_MID_Y = getHeight() / 2.0;
        //Calculate half of  draw size Y-axis
        double DRAW_SIZE_Y = ((BOX_SIZE * NUM_ROWS) + (BOX_SPACING * NUM_ROWS)) / 2;
        //Get position of first square Y-axis
        return WIN_MID_Y - DRAW_SIZE_Y;
    }
}
