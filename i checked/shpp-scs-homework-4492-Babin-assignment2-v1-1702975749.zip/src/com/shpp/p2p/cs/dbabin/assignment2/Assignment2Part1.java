package com.shpp.p2p.cs.dbabin.assignment2;

import com.shpp.cs.a.console.TextProgram;

public class Assignment2Part1 extends TextProgram {
    //Create needed variable

    public static double a;
    public static double b;
    public static double c;
    public static double D;

    public void run() {
        getNumbers();
        getDiscriminant();
        noRealRoot();
    }

    /**
     * Ask numbers
     */

    private void getNumbers() {
        a = readDouble("Please enter a: ");
        b = readDouble("Please enter b: ");
        c = readDouble("Please enter c: ");
    }

    /**
     * It's formula for get the discriminant
     */
    private void getDiscriminant() {
        D = (b * b) - (4 * a * c);
    }

    /**
     * If a == 0 equation is not quadratic and don't have roots
     * If discriminant less than 0 we can't get root
     */
    private void noRealRoot() {
        if (a == 0 || D < 0) {
            println("There are no real roots");
        } else {
            //If the equation is correct
            getRoots();
        }
    }

    /**
     *Here we get two roots and return answer.
     *If x1==x2 it's means equation have only one root
     */

    private void getRoots() {
        double x1 = ((b - b * 2) + Math.sqrt(D)) / (2 * a);
        double x2 = ((b - b * 2) - Math.sqrt(D)) / (2 * a);

        if (x1 == x2) {
            println("There is one root: " + x2);
        } else {
            println("There are two roots: " + x1 + " and " + x2);
        }
    }
}