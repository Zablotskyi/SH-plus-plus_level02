package com.shpp.p2p.cs.ozabolotniy.assignment2;

import acm.graphics.GOval;
import acm.graphics.GRect;
import com.shpp.cs.a.graphics.WindowProgram;

import java.awt.*;
/* Part 2 — Illusory contours */

public class Assignment2Part2 extends WindowProgram {
    /* a constant for resizing the circle */
    static final double sizeCircle = 150;
    /* constant to resize screen width */
    public static final int APPLICATION_WIDTH = 600;

    /* constant to resize screen height */
    public static final int APPLICATION_HEIGHT = 550;

    public void run() {
        MakeFirstCircle();
        MakeSecondCircle();
        MakeThirdCircle();
        MakeFourthCircle();
        MakeRect();
    }

    /* method to create a centered rectangle */
    private void MakeRect() {
        GRect rect = new GRect(getWidth() / 2.0 - ((getWidth() - sizeCircle) / 2),
                getHeight() / 2.0 - ((getHeight() - sizeCircle) / 2),
                getWidth() - (sizeCircle),
                getHeight() - sizeCircle);
        rect.setFilled(true);
        rect.setFillColor(Color.white);
        rect.setColor(Color.white);
        this.add(rect);
    }

    /* method for creating the fourth circle, in the upper right corner */
    private void MakeFourthCircle() {
        GOval fourthCircle = new GOval(getWidth() - sizeCircle, 0, sizeCircle, sizeCircle);
        fourthCircle.setFilled(true);
        fourthCircle.setFillColor(Color.black);
        this.add(fourthCircle);
    }

    /* method for creating the third circle, in the upper left corner */
    private void MakeThirdCircle() {
        GOval thirdCircle = new GOval(0, 0, sizeCircle, sizeCircle);
        thirdCircle.setFilled(true);
        thirdCircle.setFillColor(Color.black);
        this.add(thirdCircle);
    }

    /* method for creating a second circle, in the lower left corner */
    private void MakeSecondCircle() {
        GOval secondCircle = new GOval(0, getHeight() - sizeCircle, sizeCircle, sizeCircle);
        secondCircle.setFilled(true);
        secondCircle.setFillColor(Color.black);
        this.add(secondCircle);
    }

    /* method for creating the first circle, in the lower right corner */
    private void MakeFirstCircle() {
        GOval firstCircle = new GOval(getWidth() - sizeCircle, getHeight() - sizeCircle, sizeCircle, sizeCircle);
        firstCircle.setFilled(true);
        firstCircle.setFillColor(Color.black);
        this.add(firstCircle);
    }
}
