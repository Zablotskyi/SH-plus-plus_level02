package com.shpp.p2p.cs.ozabolotniy.assignment2;

import acm.graphics.GLabel;
import acm.graphics.GRect;
import com.shpp.cs.a.graphics.WindowProgram;

import java.awt.*;


/* Part 4 - Tricolor flags */

public class Assignment2Part4 extends WindowProgram {
    /* constant to give the width of the flag */
    static final double WidthFlag = 500;
    /* constant to give the height of the flag */
    static final double HeightFlag = 250;
    /* constant to create a custom color for the flag, namely a shade of orange */
    private static final Color ORANGECOLOR = new Color(255, 136, 62);
    /* constant to create its color, namely the green shade for the flag */
    private static final Color GREENCOLOR = new Color(22, 155, 98);

    public void run() {
        MakeCenterTheFlag();
        MakeLeftSideTheFlag();
        MakeRightSideTheFlag();
        MakeTextAboutCountry();
    }

    /* method for creating a text description of which country's flag */
    private void MakeTextAboutCountry() {
        GLabel textDescription = new GLabel("Flag is Ireland",
                getWidth() - 220,
                getHeight() - 6);
        textDescription.setColor(Color.black);
        textDescription.setFont("Verdana-30");
        add(textDescription);
    }

    /* method for creating the right part of the flag (the orange part) */
    private void MakeRightSideTheFlag() {
        GRect rightSide = new GRect(((getWidth() / 2.0) - ((WidthFlag / 3.0) / 2) + WidthFlag / 3.0),
                getHeight() / 2.0 - (HeightFlag / 2),
                WidthFlag / 3,
                HeightFlag);
        rightSide.setFilled(true);
        rightSide.setFillColor(ORANGECOLOR);
        add(rightSide);
    }

    /* method for creating the left part of the flag (green part ) */
    private void MakeLeftSideTheFlag() {
        GRect leftSide = new GRect(((getWidth() / 2.0) - ((WidthFlag / 3.0) / 2) - WidthFlag / 3.0),
                getHeight() / 2.0 - (HeightFlag / 2),
                WidthFlag / 3,
                HeightFlag);
        leftSide.setFilled(true);
        leftSide.setFillColor(GREENCOLOR);
        add(leftSide);
    }

    /* method for creating the center of the flag (white part) */
    private void MakeCenterTheFlag() {
        GRect centerSide = new GRect((getWidth() / 2.0) - ((WidthFlag / 3.0) / 2),
                getHeight() / 2.0 - (HeightFlag / 2),
                WidthFlag / 3,
                HeightFlag);
        centerSide.setFilled(true);
        centerSide.setFillColor(Color.white);
        add(centerSide);
    }
}
