package com.shpp.p2p.cs.ozabolotniy.assignment2;

import com.shpp.cs.a.console.TextProgram;
/* Part 1 - Quadratic equation */

public class Assignment2Part1 extends TextProgram {
    public void run() {
        /* we get three numbers for the equation */
        double a = readDouble("Please enter a:");
        double b = readDouble("Please enter b:");
        double c = readDouble("Please enter c:");
        /* we count the discriminant */
        double discriminator = ((b * b) - (4 * a * c));
        /* if the discriminant is less than 0, there are no roots */
        if (discriminator < 0) {
            println("There are no real roots");
        }

        /*if the discriminant is greater than 0, then we have two different roots*/
        if (discriminator > 0) {
            /* we find the root of the discriminant */
            double RootOfDiscriminant = Math.sqrt(discriminator);
            /* find the roots of the equation and output them to the console (x1 and x2) */
            double x1 = (-b + RootOfDiscriminant) / (2 * a);
            double x2 = (-b - RootOfDiscriminant) / (2 * a);
            println("There are two roots:" + x1 + " and " + x2);
        }
        /* if the discriminant is equal to 0, then we have one root */
        if (discriminator == 0) {
            /* we find the only root of the equation and derive it */
            double x1 = -b / 2 * a;
            println("There is one root:" + x1);
        }
    }
}
