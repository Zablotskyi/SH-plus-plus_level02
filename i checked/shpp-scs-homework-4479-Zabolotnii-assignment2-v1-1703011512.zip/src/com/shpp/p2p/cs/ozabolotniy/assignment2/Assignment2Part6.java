package com.shpp.p2p.cs.ozabolotniy.assignment2;

import acm.graphics.GOval;
import com.shpp.cs.a.graphics.WindowProgram;

import java.awt.*;
/* Part 6 - Caterpillars */

public class Assignment2Part6 extends WindowProgram {
    /* constant for changing the number of caterpillars segments */
    static final double SegmentsCaterpillar = 8;
    /* constant for resizing the caterpillars segment */
    static final double SizeCaterpillar = 40;
    /* change position caterpillars for y coordinate*/
    static final double PositionCaterpillarsY = 80;


    public void run() {
        /* we create a length caterpillar */
        for (int i = 1; i <= SegmentsCaterpillar; i++) {
            /* we create upper segments */
            if (i % 2 == 0) {
                GOval upperSegment = new GOval((i * (SizeCaterpillar/1.5)),
                        PositionCaterpillarsY,
                        SizeCaterpillar,
                        SizeCaterpillar);
                upperSegment.setFilled(true);
                upperSegment.setFillColor(Color.GREEN);
                add(upperSegment);
            }
            /* we create the lower segments */
            else {
                GOval lowerSegment = new GOval(i * (SizeCaterpillar / 1.5),
                        PositionCaterpillarsY + SizeCaterpillar/2,
                        SizeCaterpillar,
                        SizeCaterpillar);
                lowerSegment.setFilled(true);
                lowerSegment.setFillColor(Color.GREEN);
                add(lowerSegment);
            }
        }
    }
}


