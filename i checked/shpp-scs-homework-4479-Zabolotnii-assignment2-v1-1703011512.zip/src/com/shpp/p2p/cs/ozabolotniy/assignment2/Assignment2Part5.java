package com.shpp.p2p.cs.ozabolotniy.assignment2;

import acm.graphics.GRect;
import com.shpp.cs.a.graphics.WindowProgram;

import java.awt.*;

/* Part 5 optical illusion */

public class Assignment2Part5 extends WindowProgram {
    /* The number of rows and columns in the grid, respectively. */
    private static final int NUM_ROWS = 5;
    private static final int NUM_COLS = 5;

    /* The width and height of each box. */
    private static final double BOX_SIZE = 68;

    /* The horizontal and vertical spacing between the boxes. */
    private static final double BOX_SPACING = 26;

    public void run() {
        MakeRowsCubes();
    }

    /* method for creating rows of squares and centering them all */
    private void MakeRowsCubes() {
        for (int j = 0; j < NUM_COLS; j++) {
            for (int i = 0; i < NUM_ROWS; i++) {
                GRect squares = new GRect((getWidth() / 2.0 + ((BOX_SIZE + BOX_SPACING) * i) - ((NUM_ROWS * (BOX_SIZE + BOX_SPACING)) / 2)),
                        (getHeight() / 2.0 + ((BOX_SIZE + BOX_SPACING) * j) - ((NUM_COLS * (BOX_SIZE + BOX_SPACING)) / 2) + BOX_SPACING / 2),
                        BOX_SIZE,
                        BOX_SIZE);
                squares.setFilled(true);
                squares.setFillColor(Color.black);
                add(squares);
            }
        }
    }
}

